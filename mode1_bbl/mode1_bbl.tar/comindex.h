      common /index/  li(ntot),lj(ntot),lk(ntot)
