c      double precision d,d2,d3
       common  /leng/  zpts(0:nzm),wg(0:nzm),zpts2(0:64)
       common /dervop/ d(0:nzm,0:nzm),d2(0:nzm,0:nzm),d3(0:nzm,0:nzm)
