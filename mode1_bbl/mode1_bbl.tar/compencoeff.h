      common /pencoeff/ facdir,facneumn,facrobin

