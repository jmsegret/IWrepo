       common /scratch/ ox(nxpp,ny,nz),oy(nxpp,ny,nz),
     >                  oz(nxpp,ny,nz)
