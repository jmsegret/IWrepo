        common /meanvalues/ umean(ny,nz),vmean(ny,nz),wmean(ny,nz),
     >tempmean(nz),
     >dumeandz(ny,nz),dumeandy(ny,nz),
     >t11mean(ny,nz),t12mean(ny,nz),t13mean(ny,nz),
     >t22mean(ny,nz),t23mean(ny,nz),t33mean(ny,nz)
