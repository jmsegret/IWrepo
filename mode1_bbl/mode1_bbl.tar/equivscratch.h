      equivalence (ox,o1),  (oy,o2),  (oz,o3)
