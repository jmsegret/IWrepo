        common /rmsvalues/ urms(ny,nz),vrms(ny,nz),wrms(ny,nz),
     >                     urms0(ny,nz),vrms0(ny,nz),wrms0(ny,nz)
        common /rmstemp/ temprms,temprms0
