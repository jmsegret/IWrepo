      common  /fft/  trigsx(nxf),trigsy(nyf),
     1                work(ntot),scaley,ifaxx(13),ifaxy(13)
c     common /vfft/ trigsz(nzf),scalez,ifaxz(13)

      common /fft1d/ trigsy1d(nyf),work1d((ny+2)*nz),ifaxy1d(13)
