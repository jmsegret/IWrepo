C-Contains the two main terms of the rotational form of the
C-improved pressure BC
       common /pressbc/wnl(nxpp,ny,2),wviscrot(nxpp,ny,2)

