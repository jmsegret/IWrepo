       common  /wave/  xw(nxhp),yw(ny),
     >                 xsq(nxhp),ysq(ny),
     >                 alpha,beta
