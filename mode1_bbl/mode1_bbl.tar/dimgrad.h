      dimension dudx(nxpp,ny,nz),dudy(nxpp,ny,nz),
     >          dudz(nxpp,ny,nz),
     >          dvdx(nxpp,ny,nz),dvdy(nxpp,ny,nz),
     >          dvdz(nxpp,ny,nz),
     >          dwdx(nxpp,ny,nz),dwdy(nxpp,ny,nz),
     >          dwdz(nxpp,ny,nz),
     >          dtdx(nxpp,ny,nz),dtdy(nxpp,ny,nz),
     >          dtdz(nxpp,ny,nz)
 
