       common /param/  pr,ra,tempgrad
       common /condts/ xnu,xkappa,expan,grav,tdiff,brunt,rho0,dtin
       common /rotat/  omz
       common /velinit/ umax
       common /numaux/ xnum,xnup,facvelp,facvelm,
     >                 aa,aap,aam,daa
