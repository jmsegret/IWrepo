      common /penaltyparams/alphap(nsubd),betap(nsubd),
     >                      gammap(nsubd),deltap(nsubd),
     >                      tau1(nsubd),tau2(nsubd),
     >                      omega

