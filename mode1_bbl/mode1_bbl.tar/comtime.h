      common  /timevars/  t,dt,cdt,nsteps
      common /fachelm/ facvel,fact
      common /vardtflags/ ivardt,idtstep
c      common /anim/ianim,ianimc
 
