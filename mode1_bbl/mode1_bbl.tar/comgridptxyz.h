      common /comgridptxyz/ x(nx),y(ny),z(nz),zf(nz2),dx,dy
