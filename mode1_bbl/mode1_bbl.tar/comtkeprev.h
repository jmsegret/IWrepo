      common /tkeprevc/ tkeprev
