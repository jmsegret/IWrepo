      common /specfilterparams/ amp,p,fackc,
     >                          pf,fackcbv
