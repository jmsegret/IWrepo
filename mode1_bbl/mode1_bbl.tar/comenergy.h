       common /energetics/ tketot,u1tke,u2tke,u3tke,
     >tkemean,prody,prodz,prod,bflux,epsilon,epssgs,epstot,
     >tempvar,chi,chisgs,chitot
