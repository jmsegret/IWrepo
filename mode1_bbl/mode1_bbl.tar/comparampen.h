       common /penaltyparams/alpha(nsubd),beta(nsubd),
     >                      gamma(nsubd),delta(nsubd),
     >                      tau1(nsubd),tau2(nsubd) 
      common /comomega/omega

