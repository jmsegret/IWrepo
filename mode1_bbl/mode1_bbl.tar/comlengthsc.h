        common /lengthscales/wakely,wakelz,thorperms 
        common /wakevel/ udefy,udefz
        common /wakectr/ yc,zc
