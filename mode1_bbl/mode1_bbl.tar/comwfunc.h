      common /comwfunc/ wp(nxhp,ny,nz),wm(nxhp,ny,nz)
