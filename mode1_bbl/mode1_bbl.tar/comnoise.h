	common /comnoise/fnoise3d(nxpp,ny,nz)
