C-Stores in a common block the tabulated values of the
C-Boyd-Vandeven Spectral filter
      common /bvfilter/ bvf(nz)
