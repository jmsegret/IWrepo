       common /bc  /   tubc(nxpp,ny),tbbc(nxpp,ny),
     > uw(nxpp,ny,2),vw(nxpp,ny,2),ww(nxpp,ny,2)

