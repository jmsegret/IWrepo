      common  /ab/  fac1,fac2,fac3
      common  /bdf/ bdf1,bdf2,bdf3,bdfv
 
