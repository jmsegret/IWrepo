      parameter (irobin=2,ineumann=1,idirichlet=0)
