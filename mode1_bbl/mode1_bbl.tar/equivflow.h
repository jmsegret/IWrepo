       equivalence (u,uc),   (v,vc),   (w,wc),   (temp,tc)
