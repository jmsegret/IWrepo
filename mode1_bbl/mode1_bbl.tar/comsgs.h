      common /comsgs/  t11(nxpp,ny,nz),t12(nxpp,ny,nz),t13(nxpp,ny,nz),
     >              t22(nxpp,ny,nz),t23(nxpp,ny,nz),t33(nxpp,ny,nz),
     >              th1(nxpp,ny,nz),th2(nxpp,ny,nz),th3(nxpp,ny,nz)
