       common  /wave/  xw(nxhp),yw(ny),zw(nzf),
     >                 xsq(nxhp),ysq(ny),zsq(nzf),
     >                 alpha,beta,gamma
