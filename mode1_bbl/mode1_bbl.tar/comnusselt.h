      common /nusselt/ nuss(nz),tmean(nz),tder(nz),tavl,tavu
