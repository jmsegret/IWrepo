      common /filterz3ptrapz/ atpz(nz2),btpz(nz2),ctpz(nz2)
