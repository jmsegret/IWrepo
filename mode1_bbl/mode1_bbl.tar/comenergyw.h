       common /energeticsw/ tketotw,u1tkew,u2tkew,u3tkew,
     >prodyw,prodzw,prodw,bfluxw,
     >epsilonw,epssgsw,epstotw,
     >tempvarw,chiw,chisgsw,chitotw
