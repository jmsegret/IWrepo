      common /comddzwfunc/ dwmbot(nxhp,ny),dwpbot(nxhp,ny),
     >                     d2wmtop(nxhp,ny),d2wptop(nxhp,ny)
