       equivalence (tn,tnc), (un,unc), (vn,vnc), (wn,wnc)
       equivalence (tnm,tnmc), (unm,unmc), (vnm,vnmc), (wnm,wnmc)
