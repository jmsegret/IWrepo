      complex o1(nxhp,ny,nz),o2(nxhp,ny,nz),o3(nxhp,ny,nz),
     >        tc(nxhp,ny,nz),uc(nxhp,ny,nz),vc(nxhp,ny,nz),
     >        wc(nxhp,ny,nz),
c    >        unc(nxhp,ny,nz),vnc(nxhp,ny,nz),
c    >        wnc(nxhp,ny,nz),tnc(nxhp,ny,nz),
c    >        unmc(nxhp,ny,nz),vnmc(nxhp,ny,nz),
c    >        wnmc(nxhp,ny,nz),tnmc(nxhp,ny,nz),
     >        suc(nxhp,ny,nz),svc(nxhp,ny,nz),swc(nxhp,ny,nz),
     >        stc(nxhp,ny,nz)
     
