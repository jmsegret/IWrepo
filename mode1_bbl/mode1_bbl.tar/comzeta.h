      common /comzeta/ zetap(nxhp,ny,nz),zetam(nxhp,ny,nz)
