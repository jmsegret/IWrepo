       parameter (nzsq=20000) 
       common /mat/ sa(nzsq),ija(nzsq)
