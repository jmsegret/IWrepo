C-Use the following strictly for 2-D transforms of a strictly 2-D array
c     common  /fftw/  planfft,planifft,ar(nx,ny),ac(nxhp,ny)
C-Use the following for nz transforms of 3-D array
      common  /fftw/  planfft,planifft,bin(nxpp,ny,nz),bout(nxhp,ny,nz)
      
