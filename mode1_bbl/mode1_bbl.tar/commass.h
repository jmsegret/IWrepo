      common /mass/    divg(nxpp,ny,nz)
