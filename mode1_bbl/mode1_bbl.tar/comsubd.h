      common /comsubd/ z0(nsubd),zh(nsubd),zaux(nzaux),
     >subdlen(nsubd),xlen,ylen,zlen,isubdtype(nsubd),KLi,KUi
