       equivalence (dudx,dudxc),   (dudy,dudyc),   (dudz,dudzc),
     >            (dvdx,dvdxc),   (dvdy,dvdyc),   (dvdz,dvdzc),
     >            (dwdx,dwdxc),   (dwdy,dwdyc),   (dwdz,dwdzc),
     >            (dtdx,dtdxc),   (dtdy,dtdyc),   (dtdz,dtdzc)
