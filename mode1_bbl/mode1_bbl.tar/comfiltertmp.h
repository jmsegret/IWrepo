      common /comfiltertmp/ tmps1(nxpp,ny,nz),tmps2(nxpp,ny,nz),
     >tmps3(nxpp,ny,nz),tmps4(nxpp,ny,nz),tmps5(nxpp,ny,nz),
     >tmps6(nxpp,ny,nz)

