!-A Common bloack for the wave packet parameters
!-A.M.A 02-15-2008
!------------------------------------------------------------------------
      common /wavepack/ xacrit, xkcrit, xmcrit, xomega,uo
      common /f0zloc/ zcen,xbcrit,zdim,zsh,xacu
!------------------------------------------------------------------------



