      complex dudxc(nxhp,ny,nz),dudyc(nxhp,ny,nz),dudzc(nxhp,ny,nz),
     >        dvdxc(nxhp,ny,nz),dvdyc(nxhp,ny,nz),dvdzc(nxhp,ny,nz),
     >        dwdxc(nxhp,ny,nz),dwdyc(nxhp,ny,nz),dwdzc(nxhp,ny,nz),
     >        dtdxc(nxhp,ny,nz),dtdyc(nxhp,ny,nz),dtdzc(nxhp,ny,nz)
