       common  /wave/  xw(nxhp),yw(ny),zw(nzfl),
     >                 xsq(nxhp),ysq(ny),zsq(nzfl),
     >                 alpha,beta,gamma
