C-These are values of the advective term at levels (n), (n-1) & (n-2)
       common /matrix/ su(nxpp,ny,nz),sv(nxpp,ny,nz),
     >                 sw(nxpp,ny,nz),st(nxpp,ny,nz),
     >                 sun(nxpp,ny,nz),svn(nxpp,ny,nz),
     >                 swn(nxpp,ny,nz),stn(nxpp,ny,nz),
     >                 sunm(nxpp,ny,nz),svnm(nxpp,ny,nz),
     >                 swnm(nxpp,ny,nz),stnm(nxpp,ny,nz)
