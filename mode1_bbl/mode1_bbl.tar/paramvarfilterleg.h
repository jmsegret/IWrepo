      parameter (iu=1,iv=2,iw=3,it=4,
     >           izeta=5,izetap=6,izetam=7)
