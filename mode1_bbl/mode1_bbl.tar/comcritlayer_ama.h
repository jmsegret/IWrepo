C-A Common bloack for the wave packet parameters
C-A.M.A 02-15-2008
c------------------------------------------------------------------------
            parameter  (tshutoff=125,xacrit=0.015,xkcrit=2.*3.1416/2.,
           &             xmcrit=2*3.1416/0.25,xomega=0.03895)
            parameter  (zcen=1.5,xbcrit=6.0,zdim=2.0)
c------------------------------------------------------------------------


,
