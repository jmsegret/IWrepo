C-Store the maximum number of iterations used in BCG solver
       common /combcg/ itmax
