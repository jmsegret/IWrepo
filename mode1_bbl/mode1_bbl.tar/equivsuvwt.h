      equivalence (su,suc), (sv,svc), (sw,swc), (st,stc)
